# Ocular Tumor Classification Modern Flask Portal

## Important fix
This version does not use Jinja variables in the HTML view.
So the portal will not show statements like `{% if error %}` or `{{ prediction }}`.

The frontend is a static `index.html`.
The backend sends prediction results through JSON API.

## Single-folder structure
Keep these files in the same folder:

- app.py
- index.html
- requirements.txt
- model.keras  (optional)

No templates folder is required.

## Run

```bash
pip install -r requirements.txt
python app.py
```

Open:

```bash
http://127.0.0.1:5000
```

Do not open `index.html` directly for prediction. Open the Flask URL above.

## Model loading options

Option 1:
Place `model.keras` in the same folder as `app.py`.

Option 2:
Click "Load Model from PC" in the web portal.

Option 3:
Paste the full model path into the model path panel.

The selected path is saved in:

```bash
model_path.txt
```

## Developer
Developed by Hamza Shahbaz  
Department of Computer Science, Government College University Faisalabad  
Email: muhammadhamza221024@gmail.com  

Fully available for public use free of cost.
