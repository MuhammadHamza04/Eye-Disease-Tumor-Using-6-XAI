import base64
from pathlib import Path

import cv2
import numpy as np
import tensorflow as tf
from flask import Flask, request, jsonify, send_file

try:
    import tkinter as tk
    from tkinter import filedialog
    TKINTER_AVAILABLE = True
except Exception:
    TKINTER_AVAILABLE = False


app = Flask(__name__)

BASE_DIR = Path(__file__).resolve().parent
INDEX_FILE = BASE_DIR / "index.html"
MODEL_PATH_FILE = BASE_DIR / "model_path.txt"

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}
IMG_SIZE = 224

# IMPORTANT:
# Keep this class order exactly the same as your model training class_indices.
CLASS_NAMES = [
    "Choroidal Hemangioma (CH)",
    "Choroidal Osteoma (CO)",
    "Normal",
    "Retinal Capillary Hemangioma (RCH)",
    "Retinoblastoma (RB)",
    "Uveal Melanoma (UM)"
]

model = None
loaded_model_path = None


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def save_model_path(path_value):
    MODEL_PATH_FILE.write_text(str(path_value), encoding="utf-8")


def read_saved_model_path():
    if MODEL_PATH_FILE.exists():
        saved_path = MODEL_PATH_FILE.read_text(encoding="utf-8").strip()
        if saved_path:
            return saved_path
    return None


def find_default_model():
    saved_path = read_saved_model_path()
    if saved_path and Path(saved_path).exists():
        return saved_path

    same_folder_model = BASE_DIR / "model.keras"
    if same_folder_model.exists():
        return str(same_folder_model)

    return None


def choose_model_dialog():
    """
    Opens a model file picker on the server computer.
    This works for local desktop Flask use.
    It may not work on headless hosting, Kaggle, Colab, or cPanel.
    """
    if not TKINTER_AVAILABLE:
        raise RuntimeError("Tkinter file dialog is not available in this environment.")

    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)

    selected_path = filedialog.askopenfilename(
        title="Select trained Keras model file",
        filetypes=[
            ("Keras model", "*.keras"),
            ("H5 model", "*.h5"),
            ("All files", "*.*")
        ]
    )

    root.destroy()

    if not selected_path:
        raise RuntimeError("No model file was selected.")

    return selected_path


def load_model_from_path(path_value):
    global model, loaded_model_path

    model_file = Path(path_value)

    if not model_file.exists():
        raise FileNotFoundError(f"Model file not found: {model_file}")

    if model_file.suffix.lower() not in [".keras", ".h5"]:
        raise ValueError("Please select a valid .keras or .h5 model file.")

    model = tf.keras.models.load_model(str(model_file), compile=False)
    loaded_model_path = str(model_file)
    save_model_path(loaded_model_path)

    return loaded_model_path


def ensure_model_loaded(open_dialog_if_missing=False):
    global model, loaded_model_path

    if model is not None:
        return loaded_model_path

    model_path = find_default_model()

    if model_path:
        return load_model_from_path(model_path)

    if open_dialog_if_missing:
        selected_model_path = choose_model_dialog()
        return load_model_from_path(selected_model_path)

    raise RuntimeError(
        "No model is loaded. Put model.keras in this folder, enter model path, or click Load Model from PC."
    )


def preprocess_image_from_bytes(file_bytes):
    np_arr = np.frombuffer(file_bytes, np.uint8)
    image = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

    if image is None:
        raise ValueError("Invalid image file. Please upload a valid fundus image.")

    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    image = cv2.resize(image, (IMG_SIZE, IMG_SIZE))

    yuv = cv2.cvtColor(image, cv2.COLOR_RGB2YUV)
    y_channel, u_channel, v_channel = cv2.split(yuv)

    clahe = cv2.createCLAHE(clipLimit=1.0, tileGridSize=(8, 8))
    y_channel = clahe.apply(y_channel)

    enhanced_yuv = cv2.merge((y_channel, u_channel, v_channel))
    enhanced_rgb = cv2.cvtColor(enhanced_yuv, cv2.COLOR_YUV2RGB)
    enhanced_rgb = cv2.GaussianBlur(enhanced_rgb, (3, 3), 0)

    enhanced_rgb = enhanced_rgb.astype("float32") / 255.0
    enhanced_rgb = np.expand_dims(enhanced_rgb, axis=0)

    return enhanced_rgb


def image_to_base64(file_bytes, filename):
    ext = filename.rsplit(".", 1)[1].lower() if "." in filename else "png"
    if ext == "jpg":
        ext = "jpeg"
    encoded = base64.b64encode(file_bytes).decode("utf-8")
    return f"data:image/{ext};base64,{encoded}"


@app.route("/", methods=["GET"])
def home():
    return send_file(INDEX_FILE)


@app.route("/api/status", methods=["GET"])
def api_status():
    global model, loaded_model_path

    if model is None:
        try:
            default_path = find_default_model()
            if default_path:
                load_model_from_path(default_path)
        except Exception:
            pass

    return jsonify({
        "model_loaded": model is not None,
        "model_path": loaded_model_path,
        "class_names": CLASS_NAMES,
        "same_folder_model_exists": (BASE_DIR / "model.keras").exists(),
        "saved_model_path_exists": MODEL_PATH_FILE.exists(),
        "tkinter_available": TKINTER_AVAILABLE
    })


@app.route("/api/load-model", methods=["POST"])
def api_load_model():
    try:
        selected_path = choose_model_dialog()
        loaded_path = load_model_from_path(selected_path)

        return jsonify({
            "status": "success",
            "message": "Model loaded successfully.",
            "model_path": loaded_path
        })

    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500


@app.route("/api/load-model-path", methods=["POST"])
def api_load_model_path():
    try:
        data = request.get_json(silent=True) or {}
        model_path = (data.get("path") or "").strip()

        if not model_path:
            return jsonify({
                "status": "error",
                "message": "Please enter a valid model path."
            }), 400

        loaded_path = load_model_from_path(model_path)

        return jsonify({
            "status": "success",
            "message": "Model loaded successfully from entered path.",
            "model_path": loaded_path
        })

    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500


@app.route("/api/predict", methods=["POST"])
def api_predict():
    try:
        ensure_model_loaded(open_dialog_if_missing=True)

        if "image" not in request.files:
            return jsonify({"status": "error", "message": "No image uploaded."}), 400

        file = request.files["image"]

        if file.filename == "":
            return jsonify({"status": "error", "message": "Please choose an image first."}), 400

        if not allowed_file(file.filename):
            return jsonify({
                "status": "error",
                "message": "Only JPG, JPEG, PNG, and WEBP files are allowed."
            }), 400

        file_bytes = file.read()
        processed_image = preprocess_image_from_bytes(file_bytes)
        probabilities = model.predict(processed_image)[0]

        predicted_index = int(np.argmax(probabilities))
        predicted_class = CLASS_NAMES[predicted_index]
        confidence = round(float(probabilities[predicted_index]) * 100, 2)

        all_predictions = [
            {
                "class_name": CLASS_NAMES[i],
                "probability": round(float(probabilities[i]) * 100, 2)
            }
            for i in range(len(CLASS_NAMES))
        ]

        all_predictions = sorted(
            all_predictions,
            key=lambda item: item["probability"],
            reverse=True
        )

        return jsonify({
            "status": "success",
            "prediction": predicted_class,
            "confidence": confidence,
            "all_predictions": all_predictions,
            "image_data": image_to_base64(file_bytes, file.filename),
            "model_path": loaded_model_path
        })

    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500


if __name__ == "__main__":
    try:
        default_model_path = find_default_model()
        if default_model_path:
            load_model_from_path(default_model_path)
            print(f"Model loaded automatically from: {default_model_path}")
        else:
            print("No model found yet. Use the portal to load model.keras.")
    except Exception as startup_error:
        print(f"Startup model loading skipped: {startup_error}")

    app.run(debug=True, use_reloader=False, threaded=False, host="127.0.0.1", port=5000)
